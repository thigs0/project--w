from django.urls import path
from . import views

urlpatterns = [
    path('', views.card_list_view, name='card_list'),
    path('<int:pk>/', views.card_detail_view, name='card_detail'),
    path('<int:pk>/edit/', views.card_edit_view, name='card_edit'),
    path('<int:pk>/delete/', views.card_delete_view, name='card_delete'),
    path('create/', views.card_create_view, name='card_create'),
]