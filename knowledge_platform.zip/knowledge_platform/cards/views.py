from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Card

def card_list_view(request):
    """Lista todos os cards"""
    cards = Card.objects.all()
    area_filter = request.GET.get('area')
    
    if area_filter:
        cards = cards.filter(area=area_filter)
    
    context = {
        'cards': cards,
        'area_choices': Card.AREA_CHOICES,
        'selected_area': area_filter,
    }
    return render(request, 'cards/card_list.html', context)

def card_detail_view(request, pk):
    """Detalhes de um card"""
    card = get_object_or_404(Card, pk=pk)
    # Cards relacionados (mesma área)
    related_cards = Card.objects.filter(area=card.area).exclude(pk=card.pk)[:4]
    
    context = {
        'card': card,
        'related_cards': related_cards,
    }
    return render(request, 'cards/card_detail.html', context)

@login_required
def card_create_view(request):
    """Criar novo card"""
    if request.method == 'POST':
        card = Card(
            title=request.POST.get('title'),
            summary=request.POST.get('summary'),
            content=request.POST.get('content'),
            area=request.POST.get('area'),
            subareas=request.POST.get('subareas', ''),
            author=request.user
        )
        
        if 'image' in request.FILES:
            card.image = request.FILES['image']
        
        card.save()
        messages.success(request, 'Card criado com sucesso!')
        return redirect('card_detail', pk=card.pk)
    
    context = {
        'area_choices': Card.AREA_CHOICES,
    }
    return render(request, 'cards/card_create.html', context)
@login_required
def card_edit_view(request, pk):
    """Editar card (apenas autor ou admin)"""
    card = get_object_or_404(Card, pk=pk)
    
    # Verificar se o usuário é o autor ou admin
    if card.author != request.user and not request.user.is_staff:
        messages.error(request, 'Você não tem permissão para editar este card.')
        return redirect('card_detail', pk=card.pk)
    
    if request.method == 'POST':
        # Atualizar dados do card
        card.title = request.POST.get('title')
        card.summary = request.POST.get('summary')
        card.content = request.POST.get('content')
        card.area = request.POST.get('area')
        card.subareas = request.POST.get('subareas', '')
        
        # Atualizar imagem se foi enviada nova
        if 'image' in request.FILES:
            card.image = request.FILES['image']
        
        # Verificar se deve remover a imagem
        if request.POST.get('remove_image') == 'on':
            card.image = None
        
        card.save()
        messages.success(request, 'Card atualizado com sucesso!')
        return redirect('card_detail', pk=card.pk)
    
    # GET request - mostrar formulário com dados atuais
    context = {
        'card': card,
        'area_choices': Card.AREA_CHOICES,
    }
    return render(request, 'cards/card_edit.html', context)

@login_required
def card_delete_view(request, pk):
    """Excluir card (apenas autor ou admin)"""
    card = get_object_or_404(Card, pk=pk)
    
    # Verificar se o usuário é o autor ou admin
    if card.author != request.user and not request.user.is_staff:
        messages.error(request, 'Você não tem permissão para excluir este card.')
        return redirect('card_detail', pk=card.pk)
    
    if request.method == 'POST':
        card_title = card.title
        card.delete()
        messages.success(request, f'Card "{card_title}" excluído com sucesso!')
        return redirect('card_list')
    
    # GET request - mostrar confirmação
    context = {
        'card': card,
    }
    return render(request, 'cards/card_delete.html', context)