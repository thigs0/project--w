from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify
from cards.models import Card

class Project(models.Model):
    """Projeto acadêmico, colaborativo ou empresarial"""
    
    TYPE_CHOICES = [
        ('personal', 'Individual'),
        ('collaborative', 'Colaborativo'),
        ('business', 'Empresarial'),
    ]
    
    STATUS_CHOICES = [
        ('planning', 'Planejamento'),
        ('active', 'Em Andamento'),
        ('paused', '⏸Pausado'),
        ('completed', 'Concluído'),
        ('cancelled', 'Cancelado'),
    ]
    
    VISIBILITY_CHOICES = [
        ('private', 'Privado'),
        ('public', 'Público'),
        ('restricted', 'Restrito'),
    ]
    
    # Informações Básicas
    title = models.CharField(max_length=200, help_text='Título do projeto')
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    description = models.TextField(help_text='Descrição detalhada')
    area = models.CharField(max_length=100, help_text='Área de conhecimento')
    
    # Tipo e Configuração
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='personal')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='planning')
    visibility = models.CharField(max_length=20, choices=VISIBILITY_CHOICES, default='private')
    
    # Propriedade
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='owned_projects')
    members = models.ManyToManyField(User, related_name='member_projects', blank=True)
    
    # Projeto Empresarial
    company_name = models.CharField(max_length=200, blank=True, help_text='Nome da empresa')
    reward_amount = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        null=True, 
        blank=True,
        help_text='Valor da recompensa (R$)'
    )
    max_participants = models.IntegerField(
        default=10,
        help_text='Máximo de participantes no squad'
    )
    
    # Projeto Colaborativo
    requires_approval = models.BooleanField(
        default=False,
        help_text='Requer aprovação do dono para entrada'
    )
    is_open = models.BooleanField(
        default=True,
        help_text='Aceita novos membros'
    )
    
    # Relacionamentos
    cards = models.ManyToManyField(Card, blank=True, related_name='projects')
    tags = models.CharField(max_length=500, blank=True, help_text='Tags separadas por vírgula')
    
    # Metadados
    views_count = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    deadline = models.DateField(null=True, blank=True, help_text='Prazo de conclusão')
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['type', 'status']),
            models.Index(fields=['owner', '-created_at']),
            models.Index(fields=['type', 'is_open']),
        ]
    
    def __str__(self):
        return f"{self.get_type_icon()} {self.title}"
    
    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title)
            slug = base_slug
            counter = 1
            while Project.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        
        # Definir visibilidade baseada no tipo
        if self.type == 'personal' and not self.visibility:
            self.visibility = 'private'
        elif self.type == 'collaborative' and not self.visibility:
            self.visibility = 'public'
        elif self.type == 'business' and not self.visibility:
            self.visibility = 'restricted'
        
        super().save(*args, **kwargs)
    
    def get_type_icon(self):
        """Retorna emoji do tipo"""
        icons = {
            'personal': '',
            'collaborative': '',
            'business': '',
        }
        return icons.get(self.type, '')
    
    def get_status_color(self):
        """Retorna cor do status"""
        colors = {
            'planning': '#6B7A8F',
            'active': '#3498DB',
            'paused': '#F39C12',
            'completed': '#27AE60',
            'cancelled': '#E74C3C',
        }
        return colors.get(self.status, '#95A5A6')
    
    def can_view(self, user):
        """Verifica se usuário pode ver o projeto"""
        if self.visibility == 'public':
            return True
        if user == self.owner:
            return True
        if user in self.members.all():
            return True
        if self.type == 'business':  # Projetos empresariais são visíveis para candidatura
            return True
        return False
    
    def can_edit(self, user):
        """Verifica se usuário pode editar"""
        return user == self.owner
    
    def can_join(self, user):
        """Verifica se usuário pode solicitar entrada"""
        if user == self.owner:
            return False
        if user in self.members.all():
            return False
        if not self.is_open:
            return False
        if self.type == 'personal':
            return False
        if self.type == 'business' and self.members.count() >= self.max_participants:
            return False
        return True
    
    def members_count(self):
        """Conta membros"""
        return self.members.count()


class ProjectRequest(models.Model):
    """Solicitação para entrar em um projeto"""
    
    STATUS_CHOICES = [
        ('pending', 'Pendente'),
        ('approved', 'Aprovada'),
        ('rejected', 'Rejeitada'),
    ]
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='requests')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='project_requests')
    
    message = models.TextField(help_text='Mensagem de apresentação')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # Portfolio/Habilidades (para projetos empresariais)
    skills = models.CharField(max_length=500, blank=True, help_text='Habilidades separadas por vírgula')
    portfolio_link = models.URLField(blank=True, help_text='Link para portfólio/GitHub')
    
    created_at = models.DateTimeField(auto_now_add=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)
    reviewed_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='reviewed_requests'
    )
    
    class Meta:
        ordering = ['-created_at']
        unique_together = ['project', 'user']
    
    def __str__(self):
        return f"{self.user.username} → {self.project.title}"


class ProjectTask(models.Model):
    """Tarefa dentro de um projeto"""
    
    STATUS_CHOICES = [
        ('todo', 'A Fazer'),
        ('in_progress', 'Em Progresso'),
        ('review', 'Em Revisão'),
        ('done', 'Concluída'),
    ]
    
    PRIORITY_CHOICES = [
        ('low', 'Baixa'),
        ('medium', 'Média'),
        ('high', 'Alta'),
        ('urgent', 'Urgente'),
    ]
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='tasks')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='todo')
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='medium')
    
    assigned_to = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='assigned_tasks'
    )
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_tasks')
    
    deadline = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.project.title} - {self.title}"
    
    def get_priority_color(self):
        """Retorna cor da prioridade"""
        colors = {
            'low': '#95A5A6',
            'medium': '#3498DB',
            'high': '#F39C12',
            'urgent': '#E74C3C',
        }
        return colors.get(self.priority, '#95A5A6')


class ProjectComment(models.Model):
    """Comentários e discussões no projeto"""
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    
    parent = models.ForeignKey(
        'self', 
        on_delete=models.CASCADE, 
        null=True, 
        blank=True,
        related_name='replies'
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['created_at']
    
    def __str__(self):
        return f"{self.user.username} em {self.project.title}"


class ProjectMilestone(models.Model):
    """Marcos importantes do projeto"""
    
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='milestones')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    
    target_date = models.DateField()
    completed = models.BooleanField(default=False)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['target_date']
    
    def __str__(self):
        status = "Concluido" if self.completed else "Em andamento"
        return f"{status} {self.title}"