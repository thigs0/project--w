from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Count
from django.utils import timezone
from .models import Project, ProjectRequest, ProjectTask, ProjectComment, ProjectMilestone
from cards.models import Card

# ============================================================================
# VIEWS DE LISTAGEM
# ============================================================================

def project_list_view(request):
    """Lista de projetos (com filtros por tipo e visibilidade)"""
    projects = Project.objects.all()
    
    # Filtrar baseado no usuário
    if request.user.is_authenticated:
        # Mostrar: públicos + seus próprios + onde é membro + empresariais
        projects = projects.filter(
            Q(visibility='public') |
            Q(owner=request.user) |
            Q(members=request.user) |
            Q(type='business')
        ).distinct()
    else:
        # Apenas públicos para visitantes
        projects = projects.filter(visibility='public')
    
    # Filtros
    project_type = request.GET.get('type')
    status = request.GET.get('status')
    search = request.GET.get('search')
    
    if project_type:
        projects = projects.filter(type=project_type)
    if status:
        projects = projects.filter(status=status)
    if search:
        projects = projects.filter(
            Q(title__icontains=search) |
            Q(description__icontains=search) |
            Q(area__icontains=search)
        )
    
    # Ordenação
    sort = request.GET.get('sort', '-created_at')
    projects = projects.order_by(sort)
    
    # Estatísticas
    stats = {
        'total': projects.count(),
        'personal': projects.filter(type='personal').count(),
        'collaborative': projects.filter(type='collaborative').count(),
        'business': projects.filter(type='business').count(),
    }
    
    context = {
        'projects': projects,
        'stats': stats,
        'type_choices': Project.TYPE_CHOICES,
        'status_choices': Project.STATUS_CHOICES,
        'selected_type': project_type,
        'selected_status': status,
        'search_query': search,
    }
    return render(request, 'projects/project_list.html', context)


@login_required
def my_projects_view(request):
    """Meus projetos (criados + participando)"""
    owned = Project.objects.filter(owner=request.user)
    member_of = Project.objects.filter(members=request.user)
    
    context = {
        'owned_projects': owned,
        'member_projects': member_of,
    }
    return render(request, 'projects/my_projects.html', context)


# ============================================================================
# VIEWS DE DETALHES E CRUD
# ============================================================================

def project_detail_view(request, slug):
    """Detalhes de um projeto"""
    project = get_object_or_404(Project, slug=slug)
    
    # Verificar permissão de visualização
    if not project.can_view(request.user):
        messages.error(request, 'Você não tem permissão para ver este projeto.')
        return redirect('project_list')
    
    # Incrementar views (apenas uma vez por sessão) ✅ CORRIGIDO
    session_key = f'viewed_project_{project.pk}'
    if not request.session.get(session_key):
        project.views_count += 1
        project.save(update_fields=['views_count'])
        request.session[session_key] = True
    
    # Verificar se já solicitou entrada
    has_pending_request = False
    if request.user.is_authenticated:
        has_pending_request = ProjectRequest.objects.filter(
            project=project,
            user=request.user,
            status='pending'
        ).exists()
    
    # Tarefas
    tasks = project.tasks.all()
    
    # Comentários
    comments = project.comments.filter(parent=None)  # Apenas comentários principais
    
    # Milestones
    milestones = project.milestones.all()
    
    # Membros
    members = project.members.all()
    
    # Projetos relacionados
    related_projects = Project.objects.filter(
        area=project.area,
        visibility='public'
    ).exclude(pk=project.pk)[:3]
    
    context = {
        'project': project,
        'tasks': tasks,
        'comments': comments,
        'milestones': milestones,
        'members': members,
        'related_projects': related_projects,
        'has_pending_request': has_pending_request,
        'can_join': project.can_join(request.user) if request.user.is_authenticated else False,
    }
    return render(request, 'projects/project_detail.html', context)


@login_required
def project_create_view(request):
    """Criar novo projeto"""
    if request.method == 'POST':
        project = Project(
            owner=request.user,
            title=request.POST.get('title'),
            description=request.POST.get('description'),
            area=request.POST.get('area'),
            type=request.POST.get('type'),
            status=request.POST.get('status', 'planning'),
            tags=request.POST.get('tags', ''),
        )
        
        # Campos específicos por tipo
        if project.type == 'business':
            project.company_name = request.POST.get('company_name', '')
            project.reward_amount = request.POST.get('reward_amount') or None
            project.max_participants = int(request.POST.get('max_participants', 10))
        
        if project.type == 'collaborative':
            project.requires_approval = request.POST.get('requires_approval') == 'on'
            project.is_open = request.POST.get('is_open', 'on') == 'on'
        
        # Deadline
        deadline = request.POST.get('deadline')
        if deadline:
            project.deadline = deadline
        
        project.save()
        
        # Cards relacionados
        card_ids = request.POST.getlist('cards')
        if card_ids:
            cards = Card.objects.filter(id__in=card_ids)
            project.cards.set(cards)
        
        messages.success(request, f'Projeto "{project.title}" criado com sucesso!')
        return redirect('project_detail', slug=project.slug)
    
    # GET
    cards = Card.objects.all()
    
    context = {
        'type_choices': Project.TYPE_CHOICES,
        'status_choices': Project.STATUS_CHOICES,
        'cards': cards,
    }
    return render(request, 'projects/project_create.html', context)


@login_required
def project_edit_view(request, slug):
    """Editar projeto"""
    project = get_object_or_404(Project, slug=slug)
    
    if not project.can_edit(request.user):
        messages.error(request, 'Você não tem permissão para editar este projeto.')
        return redirect('project_detail', slug=project.slug)
    
    if request.method == 'POST':
        project.title = request.POST.get('title')
        project.description = request.POST.get('description')
        project.area = request.POST.get('area')
        project.status = request.POST.get('status')
        project.tags = request.POST.get('tags', '')
        
        # Campos específicos por tipo
        if project.type == 'business':
            project.company_name = request.POST.get('company_name', '')
            project.reward_amount = request.POST.get('reward_amount') or None
            project.max_participants = int(request.POST.get('max_participants', 10))
        
        if project.type == 'collaborative':
            project.requires_approval = request.POST.get('requires_approval') == 'on'
            project.is_open = request.POST.get('is_open', 'on') == 'on'
        
        # Deadline
        deadline = request.POST.get('deadline')
        if deadline:
            project.deadline = deadline
        
        project.save()
        
        # Cards
        card_ids = request.POST.getlist('cards')
        if card_ids:
            cards = Card.objects.filter(id__in=card_ids)
            project.cards.set(cards)
        else:
            project.cards.clear()
        
        messages.success(request, 'Projeto atualizado!')
        return redirect('project_detail', slug=project.slug)
    
    # GET
    cards = Card.objects.all()
    
    context = {
        'project': project,
        'status_choices': Project.STATUS_CHOICES,
        'cards': cards,
    }
    return render(request, 'projects/project_edit.html', context)


@login_required
def project_delete_view(request, slug):
    """Deletar projeto"""
    project = get_object_or_404(Project, slug=slug)
    
    if not project.can_edit(request.user):
        messages.error(request, 'Você não tem permissão para deletar este projeto.')
        return redirect('project_detail', slug=project.slug)
    
    if request.method == 'POST':
        project_title = project.title
        project.delete()
        messages.success(request, f'Projeto "{project_title}" excluído com sucesso!')
        return redirect('project_list')
    
    context = {'project': project}
    return render(request, 'projects/project_delete.html', context)


# ============================================================================
# SISTEMA DE SOLICITAÇÕES
# ============================================================================

@login_required
def project_request_join(request, slug):
    """Solicitar entrada em um projeto"""
    project = get_object_or_404(Project, slug=slug)
    
    if not project.can_join(request.user):
        messages.error(request, 'Você não pode solicitar entrada neste projeto.')
        return redirect('project_detail', slug=project.slug)
    
    # Verificar se já existe solicitação
    existing = ProjectRequest.objects.filter(
        project=project,
        user=request.user
    ).first()
    
    if existing:
        if existing.status == 'pending':
            messages.info(request, 'Você já tem uma solicitação pendente para este projeto.')
        elif existing.status == 'rejected':
            messages.error(request, 'Sua solicitação anterior foi rejeitada.')
        return redirect('project_detail', slug=project.slug)
    
    if request.method == 'POST':
        project_request = ProjectRequest.objects.create(
            project=project,
            user=request.user,
            message=request.POST.get('message'),
            skills=request.POST.get('skills', ''),
            portfolio_link=request.POST.get('portfolio_link', ''),
        )
        
        # Se não requer aprovação, aceitar automaticamente
        if not project.requires_approval:
            project_request.status = 'approved'
            project_request.reviewed_at = timezone.now()
            project_request.save()
            project.members.add(request.user)
            messages.success(request, f'Você entrou no projeto "{project.title}"!')
        else:
            messages.success(request, 'Solicitação enviada! Aguarde a aprovação do dono do projeto.')
        
        return redirect('project_detail', slug=project.slug)
    
    context = {
        'project': project,
    }
    return render(request, 'projects/project_request_join.html', context)


@login_required
def project_requests_view(request, slug):
    """Ver solicitações de entrada (apenas dono)"""
    project = get_object_or_404(Project, slug=slug)
    
    if not project.can_edit(request.user):
        messages.error(request, 'Você não tem permissão para ver as solicitações.')
        return redirect('project_detail', slug=project.slug)
    
    requests = project.requests.filter(status='pending')
    
    context = {
        'project': project,
        'requests': requests,
    }
    return render(request, 'projects/project_requests.html', context)


@login_required
def project_request_approve(request, slug, request_id):
    """Aprovar solicitação"""
    project = get_object_or_404(Project, slug=slug)
    project_request = get_object_or_404(ProjectRequest, pk=request_id, project=project)
    
    if not project.can_edit(request.user):
        messages.error(request, 'Você não tem permissão.')
        return redirect('project_detail', slug=project.slug)
    
    project_request.status = 'approved'
    project_request.reviewed_at = timezone.now()
    project_request.reviewed_by = request.user
    project_request.save()
    
    project.members.add(project_request.user)
    
    messages.success(request, f'{project_request.user.username} foi aprovado!')
    return redirect('project_requests', slug=project.slug)


@login_required
def project_request_reject(request, slug, request_id):
    """Rejeitar solicitação"""
    project = get_object_or_404(Project, slug=slug)
    project_request = get_object_or_404(ProjectRequest, pk=request_id, project=project)
    
    if not project.can_edit(request.user):
        messages.error(request, 'Você não tem permissão.')
        return redirect('project_detail', slug=project.slug)
    
    project_request.status = 'rejected'
    project_request.reviewed_at = timezone.now()
    project_request.reviewed_by = request.user
    project_request.save()
    
    messages.info(request, f'Solicitação de {project_request.user.username} foi rejeitada.')
    return redirect('project_requests', slug=project.slug)


@login_required
def project_leave(request, slug):
    """Sair do projeto"""
    project = get_object_or_404(Project, slug=slug)
    
    if request.user == project.owner:
        messages.error(request, 'Você é o dono do projeto e não pode sair.')
        return redirect('project_detail', slug=project.slug)
    
    if request.user not in project.members.all():
        messages.error(request, 'Você não é membro deste projeto.')
        return redirect('project_detail', slug=project.slug)
    
    project.members.remove(request.user)
    messages.success(request, f'Você saiu do projeto "{project.title}".')
    return redirect('project_list')