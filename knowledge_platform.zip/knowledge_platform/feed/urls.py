from django.urls import path
from . import views

urlpatterns = [
    path('', views.feed_view, name='feed'),
    path('api/posts/', views.posts_json, name='posts_json'),
    path('api/recommendations/', views.recommendations_json, name='recommendations_json'),
    path('api/notifications/', views.notifications_json, name='notifications_json'),
    path('post/create/', views.post_create_view, name='post_create'),
    path('post/<int:pk>/like/', views.post_like_view, name='post_like'),
    path('post/<int:pk>/comment/', views.post_comment_view, name='post_comment'),
    path('post/<int:pk>/insight/', views.post_insight_view, name='post_insight'),
    path('post/<int:pk>/moderate/<str:mod_type>/', views.post_moderate_view, name='post_moderate'),
    path('post/<int:pk>/comments_json/', views.comments_json_view, name='post_comments_json'),
    path('notifications/mark_read/<int:pk>/', views.notification_mark_read, name='notification_mark_read'),
]
