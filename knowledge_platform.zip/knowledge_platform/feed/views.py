from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.utils.safestring import mark_safe
from django.utils import timezone
from django.db.models import Count
from django.contrib.auth.models import User
from .models import Post, Like, Comment, Insight, Moderation, Notification
from django.views.decorators.http import require_GET, require_POST

# optional server-side markdown rendering if package installed
try:
    import markdown as md
    def render_markdown(text):
        return mark_safe(md.markdown(text, extensions=['fenced_code', 'codehilite', 'nl2br']))
except Exception:
    def render_markdown(text):
        # fallback: preserve line breaks
        return mark_safe('<p>' + text.replace('\n', '<br>') + '</p>')

def feed_view(request):
    """Feed principal de posts com paginação.

    - Retorna posts mais recentes primeiro (Post.Meta.ordering)
    - Suporta `?page=` para paginação
    - Renderiza conteúdo em HTML (markdown se disponível)
    - Anexa metadados úteis para template (avatar, time display, counts, flags)
    """
    post_list = Post.objects.select_related('author').prefetch_related('tags')

    # pagination
    page = request.GET.get('page', 1)
    per_page = 10
    paginator = Paginator(post_list, per_page)
    try:
        posts_page = paginator.page(page)
    except PageNotAnInteger:
        posts_page = paginator.page(1)
    except EmptyPage:
        posts_page = paginator.page(paginator.num_pages)

    posts = []
    for post in posts_page.object_list:
        # author info and avatar
        avatar = None
        try:
            if hasattr(post.author, 'profile') and post.author.profile.photo:
                avatar = post.author.profile.photo.url
        except Exception:
            avatar = None

        # counts and flags
        obj = {
            'id': post.pk,
            'author_name': post.author.get_full_name() or post.author.username,
            'author_username': post.author.username,
            'author_avatar': avatar,
            'created_at': post.created_at,
            'time_display': post.created_at,  # template can use humanize/naturaltime
            'content_html': render_markdown(post.content),
            'image_url': post.image.url if post.image else None,
            'tags': [t.name for t in post.tags.all()],
            'likes_count': post.likes_count(),
            'comments_count': post.comments_count(),
            'insights_count': post.insights_count(),
            'is_curated': post.is_curated(),
            'curated_count': post.curated_count(),
            'user_liked': False,
            'user_insight': False,
        }

        if request.user.is_authenticated:
            obj['user_liked'] = Like.objects.filter(user=request.user, post=post).exists()
            obj['user_insight'] = Insight.objects.filter(user=request.user, post=post).exists()

        posts.append(obj)

    # recommendations: authors with most posts (exclude current user)
    recommendations = []
    if request.user.is_authenticated:
        rec_qs = User.objects.annotate(post_count=Count('post')).exclude(pk=request.user.pk).order_by('-post_count')[:6]
    else:
        rec_qs = User.objects.annotate(post_count=Count('post')).order_by('-post_count')[:6]

    for u in rec_qs:
        recommendations.append({
            'username': u.username,
            'name': u.get_full_name() or u.username,
            'post_count': getattr(u, 'post_count', 0),
        })

    # notifications for current user
    notifications = []
    if request.user.is_authenticated:
        not_qs = Notification.objects.filter(user=request.user).order_by('-created_at')[:12]
        for n in not_qs:
            notifications.append({
                'id': n.pk,
                'actor': n.actor.get_full_name() or n.actor.username,
                'verb': n.verb,
                'post_id': n.post.pk if n.post else None,
                'read': n.read,
                'created_at': n.created_at,
            })

    context = {
        'posts': posts,
        'page_obj': posts_page,
        'paginator': paginator,
        'recommendations': recommendations,
        'notifications': notifications,
    }
    return render(request, 'feed/feed.html', context)


@require_GET
def posts_json(request):
    """Return paginated posts as JSON for frontend consumption."""
    post_list = Post.objects.select_related('author').prefetch_related('tags')
    page = int(request.GET.get('page', 1))
    per_page = int(request.GET.get('per_page', 10))
    paginator = Paginator(post_list, per_page)
    try:
        posts_page = paginator.page(page)
    except Exception:
        posts_page = paginator.page(1)

    data = []
    for post in posts_page.object_list:
        avatar = None
        try:
            if hasattr(post.author, 'profile') and post.author.profile.photo:
                avatar = post.author.profile.photo.url
        except Exception:
            avatar = None

        item = {
            'id': post.pk,
            'author_name': post.author.get_full_name() or post.author.username,
            'author_username': post.author.username,
            'author_avatar': avatar,
            'created_at': post.created_at.isoformat(),
            'content_html': render_markdown(post.content),
            'image_url': post.image.url if post.image else None,
            'tags': [t.name for t in post.tags.all()],
            'likes_count': post.likes_count(),
            'comments_count': post.comments_count(),
            'insights_count': post.insights_count(),
            'is_curated': post.is_curated(),
            'curated_count': post.curated_count(),
        }
        if request.user.is_authenticated:
            item['user_liked'] = Like.objects.filter(user=request.user, post=post).exists()
            item['user_insight'] = Insight.objects.filter(user=request.user, post=post).exists()
        else:
            item['user_liked'] = False
            item['user_insight'] = False

        data.append(item)

    return JsonResponse({
        'posts': data,
        'page': posts_page.number,
        'num_pages': paginator.num_pages,
        'total': paginator.count,
    })


@require_GET
def recommendations_json(request):
    rec = []
    if request.user.is_authenticated:
        rec_qs = User.objects.annotate(post_count=Count('post')).exclude(pk=request.user.pk).order_by('-post_count')[:8]
    else:
        rec_qs = User.objects.annotate(post_count=Count('post')).order_by('-post_count')[:8]

    for u in rec_qs:
        rec.append({'username': u.username, 'name': u.get_full_name() or u.username, 'post_count': getattr(u, 'post_count', 0)})

    return JsonResponse({'recommendations': rec})


@login_required
@require_GET
def notifications_json(request):
    qs = Notification.objects.filter(user=request.user).order_by('-created_at')[:50]
    out = []
    for n in qs:
        out.append({'id': n.pk, 'actor': n.actor.get_full_name() or n.actor.username, 'verb': n.verb, 'post_id': n.post.pk if n.post else None, 'read': n.read, 'created_at': n.created_at.isoformat()})
    return JsonResponse({'notifications': out})

@login_required
def post_create_view(request):
    """Criar novo post"""
    if request.method == 'POST':
        post = Post(
            author=request.user,
            content=request.POST.get('content')
        )
        
        if 'image' in request.FILES:
            post.image = request.FILES['image']
        
        post.save()
        # notify followers/others could be added here
        messages.success(request, 'Post publicado com sucesso!')
        return redirect('feed')
    
    return render(request, 'feed/post_create.html')

@login_required
def post_like_view(request, pk):
    """Curtir/descurtir post"""
    post = get_object_or_404(Post, pk=pk)
    like, created = Like.objects.get_or_create(user=request.user, post=post)
    
    if not created:
        like.delete()
        action = 'unliked'
    else:
        action = 'liked'
        # create notification for author
        if post.author != request.user:
            Notification.objects.create(
                user=post.author,
                actor=request.user,
                verb='curtiu seu post',
                post=post
            )
    
    return JsonResponse({
        'action': action,
        'likes_count': post.likes_count()
    })

@login_required
def post_comment_view(request, pk):
    """Comentar em um post"""
    if request.method == 'POST':
        post = get_object_or_404(Post, pk=pk)
        content = request.POST.get('content')
        
        if content:
            Comment.objects.create(
                user=request.user,
                post=post,
                content=content
            )
            # notify post author
            if post.author != request.user:
                Notification.objects.create(
                    user=post.author,
                    actor=request.user,
                    verb='comentou no seu post',
                    post=post
                )
            messages.success(request, 'Comentário adicionado!')
    
    return redirect('feed')

@login_required
def post_insight_view(request, pk):
    """Marcar post como insight"""
    post = get_object_or_404(Post, pk=pk)
    insight, created = Insight.objects.get_or_create(user=request.user, post=post)
    
    if not created:
        insight.delete()
        action = 'removed'
    else:
        action = 'added'
        # notify post author
        if post.author != request.user:
            Notification.objects.create(
                user=post.author,
                actor=request.user,
                verb='marcou insight no seu post',
                post=post
            )
    
    return JsonResponse({
        'action': action,
        'insights_count': post.insights_count()
    })

@login_required
def post_moderate_view(request, pk, mod_type):
    """Moderar post (apoiar/reportar)"""
    post = get_object_or_404(Post, pk=pk)
    
    if mod_type in ['support', 'report']:
        moderation, created = Moderation.objects.get_or_create(
            user=request.user,
            post=post,
            type=mod_type
        )
        
        if not created:
            moderation.delete()
            messages.info(request, f'{mod_type} removido.')
        else:
            messages.success(request, f'Post {mod_type}!')
            # notify author on support
            if mod_type == 'support' and post.author != request.user:
                Notification.objects.create(
                    user=post.author,
                    actor=request.user,
                    verb='apoiou o seu post',
                    post=post
                )
    
    return redirect('feed')


@login_required
def comments_json_view(request, pk):
    """Return comments for a post as JSON (used by AJAX)"""
    post = get_object_or_404(Post, pk=pk)
    comments = []
    for c in post.comment_set.select_related('user').all():
        comments.append({
            'id': c.pk,
            'user': c.user.get_full_name() or c.user.username,
            'username': c.user.username,
            'content': c.content,
            'created_at': c.created_at,
        })
    return JsonResponse({'comments': comments})


@login_required
def notification_mark_read(request, pk):
    """Mark a notification as read"""
    notif = get_object_or_404(Notification, pk=pk, user=request.user)
    notif.read = True
    notif.save()
    return JsonResponse({'status': 'ok'})
