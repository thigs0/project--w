from django.db import models
from django.contrib.auth.models import User

class Post(models.Model):
    """Post no feed social"""
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    image = models.ImageField(upload_to='posts/', blank=True, null=True)
    tags = models.ManyToManyField('Tag', blank=True, related_name='posts')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f'Post de {self.author.username} em {self.created_at}'
    
    def likes_count(self):
        return self.like_set.count()
    
    def comments_count(self):
        return self.comment_set.count()
    
    def insights_count(self):
        return self.insight_set.count()

    def curated_count(self):
        return self.moderation_set.filter(type='support').count()

    def is_curated(self):
        return self.curated_count() > 0

class Like(models.Model):
    """Curtida em um post"""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('user', 'post')
    
    def __str__(self):
        return f'{self.user.username} curtiu post {self.post.id}'

class Comment(models.Model):
    """Comentário em um post"""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['created_at']
    
    def __str__(self):
        return f'Comentário de {self.user.username} em post {self.post.id}'

class Insight(models.Model):
    """Insight marcado em um post"""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('user', 'post')
    
    def __str__(self):
        return f'Insight de {self.user.username} em post {self.post.id}'

class Moderation(models.Model):
    """Moderação/Curadoria de um post"""
    TYPE_CHOICES = [
        ('support', 'Apoiar'),
        ('report', 'Reportar'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    type = models.CharField(max_length=10, choices=TYPE_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('user', 'post', 'type')
    
    def __str__(self):
        return f'{self.user.username} {self.type} post {self.post.id}'


class Tag(models.Model):
    """Tag/Assunto para posts (por exemplo: #IA, #Matemática)"""
    name = models.CharField(max_length=64, unique=True)

    def __str__(self):
        return self.name


class Notification(models.Model):
    """Notificação para um usuário (por exemplo: alguém curtiu seu post)"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')  # recipient
    actor = models.ForeignKey(User, on_delete=models.CASCADE, related_name='actor_notifications')  # who triggered
    verb = models.CharField(max_length=140)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, null=True, blank=True)
    read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'Notification to {self.user.username}: {self.actor.username} {self.verb}'
