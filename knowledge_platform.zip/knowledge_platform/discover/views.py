from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.contrib.auth.models import User
from django.db.models import Q, Count
import json

from .models import Conversation, Message, LearningTrail, TrailStep
from cards.models import Card
from projects.models import Project

# ============================================================================
# CHATBOT IA - SISTEMA DE RECOMENDAÇÃO
# ============================================================================

def generate_ai_response(user_message, user, conversation):
    """
    Gera resposta do chatbot baseada na mensagem do usuário.
    
    Esta função analisa a mensagem e:
    1. Recomenda cards relacionados
    2. Recomenda perfis de usuários
    3. Gera trilhas de aprendizado personalizadas
    4. Responde perguntas sobre a plataforma
    """
    
    message_lower = user_message.lower()
    
    # === ANÁLISE DE INTENÇÃO ===
    
    # Intenção: Buscar cards
    if any(word in message_lower for word in ['card', 'conteúdo', 'material', 'aprender sobre', 'estudar']):
        return generate_card_recommendations(user_message, user)
    
    # Intenção: Buscar pessoas
    elif any(word in message_lower for word in ['pessoa', 'perfil', 'usuário', 'quem sabe', 'especialista', 'conhece']):
        return generate_user_recommendations(user_message, user)
    
    # Intenção: Criar trilha
    elif any(word in message_lower for word in ['trilha', 'roteiro', 'caminho', 'como aprender', 'passo a passo', 'roadmap']):
        return generate_learning_trail(user_message, user, conversation)
    
    # Intenção: Buscar projetos
    elif any(word in message_lower for word in ['projeto', 'colaborar', 'equipe', 'grupo']):
        return generate_project_recommendations(user_message, user)
    
    # Intenção: Ajuda geral
    else:
        return generate_general_help(user_message, user)


def generate_card_recommendations(query, user):
    """Recomenda cards baseados na query"""
    # Extrair palavras-chave
    keywords = [word for word in query.lower().split() if len(word) > 3]
    
    # Buscar cards relacionados
    cards = Card.objects.filter(
        Q(title__icontains=' '.join(keywords[:3])) |
        Q(summary__icontains=' '.join(keywords[:3])) |
        Q(content__icontains=' '.join(keywords[:3]))
    ).distinct()[:6]
    
    if cards.exists():
        card_list = "\n".join([f"• **{card.title}** - {card.get_area_display()}" for card in cards])
        response = f"""🎴 Encontrei alguns cards que podem te ajudar:

{card_list}

Quer que eu crie uma trilha de aprendizado personalizada com esses conteúdos?"""
    else:
        response = """🔍 Não encontrei cards específicos sobre isso, mas posso te ajudar de outras formas:

• Posso recomendar pessoas que trabalham nessa área
• Posso sugerir áreas relacionadas para explorar
• Posso criar uma trilha de aprendizado do zero

O que você prefere?"""
    
    return {
        'content': response,
        'cards': list(cards),
        'users': [],
        'show_trail_button': True
    }


def generate_user_recommendations(query, user):
    """Recomenda usuários/perfis baseados na query"""
    # Extrair palavras-chave
    keywords = [word for word in query.lower().split() if len(word) > 3]
    
    # Buscar usuários que têm cards/projetos relacionados
    users = User.objects.filter(
        Q(profile__bio__icontains=' '.join(keywords[:2])) |
        Q(profile__area_of_interest__icontains=' '.join(keywords[:2])) |
        Q(card__title__icontains=' '.join(keywords[:2])) |
        Q(card__summary__icontains=' '.join(keywords[:2]))
    ).exclude(id=user.id).distinct()[:5]
    
    if users.exists():
        user_list = "\n".join([
            f"• **{u.get_full_name() or u.username}** - {u.profile.area_of_interest if hasattr(u, 'profile') else 'Sem área definida'}"
            for u in users
        ])
        response = f"""👥 Encontrei estas pessoas que podem te ajudar:

{user_list}

Você pode seguir essas pessoas ou enviar uma mensagem para elas!"""
    else:
        response = """🔍 Não encontrei pessoas específicas sobre esse tema no momento.

Que tal:
• Criar um projeto colaborativo sobre isso?
• Explorar cards relacionados primeiro?
• Buscar em uma área mais ampla?"""
    
    return {
        'content': response,
        'cards': [],
        'users': list(users),
        'show_trail_button': False
    }


def generate_project_recommendations(query, user):
    """Recomenda projetos baseados na query"""
    keywords = [word for word in query.lower().split() if len(word) > 3]
    
    # Buscar projetos públicos relacionados
    projects = Project.objects.filter(
        Q(visibility='public') | Q(type='business')
    ).filter(
        Q(title__icontains=' '.join(keywords[:2])) |
        Q(description__icontains=' '.join(keywords[:2])) |
        Q(area__icontains=' '.join(keywords[:2]))
    ).distinct()[:5]
    
    if projects.exists():
        project_list = "\n".join([
            f"• **{p.title}** - {p.get_type_display()} ({p.members.count()} membros)"
            for p in projects
        ])
        response = f"""🚀 Encontrei estes projetos que você pode se interessar:

{project_list}

Quer saber mais sobre algum deles ou criar seu próprio projeto?"""
    else:
        response = """🚀 Ainda não temos projetos públicos sobre isso.

Você pode:
• Criar o primeiro projeto sobre esse tema
• Explorar projetos de áreas relacionadas
• Buscar pessoas interessadas nesse assunto"""
    
    return {
        'content': response,
        'cards': [],
        'users': [],
        'projects': list(projects),
        'show_trail_button': False
    }


def generate_learning_trail(query, user, conversation):
    """Gera uma trilha de aprendizado personalizada"""
    # Extrair tema principal
    keywords = [word for word in query.lower().split() if len(word) > 3]
    main_topic = ' '.join(keywords[:3])
    
    # Buscar cards relacionados para montar a trilha
    cards = Card.objects.filter(
        Q(title__icontains=main_topic) |
        Q(summary__icontains=main_topic) |
        Q(content__icontains=main_topic)
    ).distinct()[:8]
    
    # Criar trilha
    trail = LearningTrail.objects.create(
        conversation=conversation,
        user=user,
        title=f"Trilha: {main_topic.title()}",
        description=f"Trilha personalizada gerada pelo assistente para aprender sobre {main_topic}"
    )
    
    # Criar passos da trilha
    if cards.exists():
        for idx, card in enumerate(cards, 1):
            step = TrailStep.objects.create(
                trail=trail,
                order=idx,
                title=f"Estudar: {card.title}",
                description=card.summary or "Explore este conteúdo",
                estimated_hours=2
            )
            step.related_cards.add(card)
    else:
        # Trilha genérica se não houver cards
        generic_steps = [
            {"title": "Fundamentos", "desc": "Aprenda os conceitos básicos", "hours": 4},
            {"title": "Prática", "desc": "Aplique o conhecimento em exercícios", "hours": 8},
            {"title": "Projeto", "desc": "Desenvolva um projeto real", "hours": 16},
            {"title": "Aprofundamento", "desc": "Estude tópicos avançados", "hours": 12},
        ]
        
        for idx, step_data in enumerate(generic_steps, 1):
            TrailStep.objects.create(
                trail=trail,
                order=idx,
                title=step_data["title"],
                description=step_data["desc"],
                estimated_hours=step_data["hours"]
            )
    
    total_hours = sum(step.estimated_hours for step in trail.steps.all())
    
    response = f"""✨ Criei uma trilha de aprendizado personalizada para você!

📚 **{trail.title}**
⏱️ Tempo estimado: {total_hours} horas
📝 {trail.steps.count()} passos

Sua trilha foi salva e você pode acessá-la a qualquer momento!"""
    
    return {
        'content': response,
        'cards': list(cards),
        'users': [],
        'trail': trail,
        'show_trail_button': False
    }


def generate_general_help(query, user):
    """Resposta genérica e ajuda"""
    response = """👋 Olá! Sou o assistente da Evolve e estou aqui para te ajudar!

Posso te auxiliar com:

🎴 **Cards** - "Quero aprender sobre Python"
👥 **Pessoas** - "Quem conhece machine learning?"
🚀 **Projetos** - "Projetos sobre IA"
📚 **Trilhas** - "Crie uma trilha de React"

Como posso te ajudar hoje?"""
    
    return {
        'content': response,
        'cards': [],
        'users': [],
        'show_trail_button': False
    }


# ============================================================================
# VIEWS
# ============================================================================

@login_required
def discover_view(request):
    """Página principal do chatbot"""
    # Pegar ou criar conversa atual
    conversation = Conversation.objects.filter(user=request.user).first()
    
    if not conversation:
        conversation = Conversation.objects.create(user=request.user)
    
    # Pegar mensagens da conversa
    messages = conversation.messages.all()
    
    # Pegar trilhas do usuário
    trails = LearningTrail.objects.filter(user=request.user)[:5]
    
    context = {
        'conversation': conversation,
        'messages': messages,
        'trails': trails,
    }
    
    return render(request, 'discover/discover.html', context)


@login_required
@require_POST
def send_message_view(request):
    """Enviar mensagem ao chatbot (API)"""
    data = json.loads(request.body)
    user_message = data.get('message', '').strip()
    
    if not user_message:
        return JsonResponse({'error': 'Mensagem vazia'}, status=400)
    
    # Pegar ou criar conversa
    conversation = Conversation.objects.filter(user=request.user).first()
    if not conversation:
        conversation = Conversation.objects.create(user=request.user)
    
    # Salvar mensagem do usuário
    user_msg = Message.objects.create(
        conversation=conversation,
        role='user',
        content=user_message
    )
    
    # Gerar resposta da IA
    ai_response = generate_ai_response(user_message, request.user, conversation)
    
    # Salvar resposta do assistente
    assistant_msg = Message.objects.create(
        conversation=conversation,
        role='assistant',
        content=ai_response['content']
    )
    
    # Adicionar recomendações
    if ai_response.get('cards'):
        assistant_msg.recommended_cards.set(ai_response['cards'])
    if ai_response.get('users'):
        assistant_msg.recommended_users.set(ai_response['users'])
    
    # Atualizar título da conversa (usando método update_title)
    if conversation.messages.count() == 2:  # Primeira interação
        conversation.update_title()
    # Atualizar título da conversa (usando método update_title)
    if conversation.messages.count() == 2:  # Primeira interação
        conversation.update_title()
    # Atualizar título da conversa (usando método update_title)
    if conversation.messages.count() == 2:  # Primeira interação
        conversation.update_title()
    # Atualizar título da conversa (usando método update_title)
    if conversation.messages.count() == 2:  # Primeira interação
        conversation.update_title()
    # Atualizar título da conversa (usando método update_title)
    if conversation.messages.count() == 2:  # Primeira interação
        conversation.update_title()
    # Preparar resposta
    response_data = {
        'user_message': {
            'id': user_msg.id,
            'content': user_msg.content,
            'created_at': user_msg.created_at.isoformat()
        },
        'assistant_message': {
            'id': assistant_msg.id,
            'content': assistant_msg.content,
            'created_at': assistant_msg.created_at.isoformat(),
            'cards': [{'id': c.id, 'title': c.title, 'area': c.get_area_display()} for c in ai_response.get('cards', [])],
            'users': [{'id': u.id, 'username': u.username, 'name': u.get_full_name()} for u in ai_response.get('users', [])],
        }
    }
    
    if ai_response.get('trail'):
        response_data['trail'] = {
            'id': ai_response['trail'].id,
            'title': ai_response['trail'].title,
            'steps_count': ai_response['trail'].steps.count()
        }
    
    return JsonResponse(response_data)


@login_required
def new_conversation_view(request):
    """Criar nova conversa"""
    Conversation.objects.create(user=request.user)
    return redirect('discover')


@login_required
def conversation_history_view(request):
    """Ver histórico de conversas"""
    conversations = Conversation.objects.filter(user=request.user)
    
    context = {
        'conversations': conversations,
    }
    
    return render(request, 'discover/history.html', context)


@login_required
def trail_detail_view(request, trail_id):
    """Ver detalhes de uma trilha"""
    trail = get_object_or_404(LearningTrail, id=trail_id, user=request.user)
    steps = trail.steps.all()
    
    context = {
        'trail': trail,
        'steps': steps,
    }
    
    return render(request, 'discover/trail_detail.html', context)


@login_required
@require_POST
def complete_step_view(request, step_id):
    """Marcar passo da trilha como completo"""
    step = get_object_or_404(TrailStep, id=step_id, trail__user=request.user)
    step.mark_complete()
    
    return JsonResponse({
        'success': True,
        'progress': step.trail.progress_percentage
    })

@login_required
def trail_detail_view(request, trail_id):
    """Ver detalhes de uma trilha"""
    trail = get_object_or_404(LearningTrail, id=trail_id, user=request.user)
    steps = trail.steps.all()
    
    # Calcular estatísticas
    total_hours = sum(step.estimated_hours for step in steps)
    completed_count = steps.filter(completed=True).count()
    
    context = {
        'trail': trail,
        'steps': steps,
        'total_hours': total_hours,
        'completed_count': completed_count,
    }
    
    return render(request, 'discover/trail_detail.html', context)