from django.urls import path
from . import views

urlpatterns = [
    # Chatbot principal
    path('', views.discover_view, name='discover'),
    path('send/', views.send_message_view, name='send_message'),
    
    # Conversas
    path('new/', views.new_conversation_view, name='new_conversation'),
    path('history/', views.conversation_history_view, name='conversation_history'),
    
    # Trilhas de aprendizado
    path('trail/<int:trail_id>/', views.trail_detail_view, name='trail_detail'),
    path('trail/step/<int:step_id>/complete/', views.complete_step_view, name='complete_step'),
]