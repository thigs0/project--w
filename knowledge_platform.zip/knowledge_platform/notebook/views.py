from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.db.models import Q, Count, Sum
from django.utils import timezone
from datetime import timedelta
from .models import Note, Notebook, NoteRevision, StudySession
from cards.models import Card
import json

# ============================================================================
# VIEWS DE CADERNOS (NOTEBOOKS)
# ============================================================================

@login_required
def notebooks_view(request):
    """Lista de cadernos do usuário"""
    notebooks = Notebook.objects.filter(user=request.user).annotate(
        notes_count=Count('notes')
    )
    
    # Estatísticas
    total_notes = Note.objects.filter(user=request.user).count()
    
    context = {
        'notebooks': notebooks,
        'total_notes': total_notes,
        'favorites_count': notebooks.filter(is_favorite=True).count(),
    }
    return render(request, 'notebook/notebooks_list.html', context)


@login_required
def notebook_create_view(request):
    """Criar novo caderno"""
    if request.method == 'POST':
        try:
            notebook = Notebook.objects.create(
                user=request.user,
                name=request.POST.get('name'),
                description=request.POST.get('description', ''),
                color=request.POST.get('color', '#7C3AED'),
                icon=request.POST.get('icon', '📓'),
            )
            messages.success(request, f'Caderno "{notebook.name}" criado com sucesso!')
            return redirect('notebook_detail', slug=notebook.slug)
        except Exception as e:
            messages.error(request, f'Erro ao criar caderno: {str(e)}')
            return redirect('notebooks_list')
    
    return render(request, 'notebook/notebook_create.html')


@login_required
def notebook_detail_view(request, slug):
    """Detalhes de um caderno com suas notas"""
    notebook = get_object_or_404(Notebook, user=request.user, slug=slug)
    notes = notebook.notes.all()
    
    # Filtros
    status_filter = request.GET.get('status')
    priority_filter = request.GET.get('priority')
    
    if status_filter:
        notes = notes.filter(status=status_filter)
    if priority_filter:
        notes = notes.filter(priority=priority_filter)
    
    context = {
        'notebook': notebook,
        'notes': notes,
        'total_words': sum(note.word_count() for note in notes),
    }
    return render(request, 'notebook/notebook_detail.html', context)


# ============================================================================
# VIEWS DE NOTAS (NOTES)
# ============================================================================

@login_required
def notebook_view(request):
    """Dashboard principal do caderno"""
    user = request.user
    
    # Notas recentes
    recent_notes = Note.objects.filter(user=user)[:10]
    
    # Notas por status
    notes_by_status = {
        'draft': Note.objects.filter(user=user, status='draft').count(),
        'review': Note.objects.filter(user=user, status='review').count(),
        'final': Note.objects.filter(user=user, status='final').count(),
        'archived': Note.objects.filter(user=user, status='archived').count(),
    }
    
    # Estatísticas da semana
    week_ago = timezone.now() - timedelta(days=7)
    notes_this_week = Note.objects.filter(user=user, created_at__gte=week_ago).count()
    
    # Notas favoritas e fixadas
    pinned_notes = Note.objects.filter(user=user, is_pinned=True)[:5]
    favorite_notes = Note.objects.filter(user=user, is_favorite=True)[:5]
    
    # Cadernos
    notebooks = Notebook.objects.filter(user=user)[:5]
    
    # Total de palavras
    all_notes = Note.objects.filter(user=user)
    total_words = sum(note.word_count() for note in all_notes)
    total_cards_referenced = sum(note.cards.count() for note in all_notes)
    
    context = {
        'recent_notes': recent_notes,
        'notes_by_status': notes_by_status,
        'notes_this_week': notes_this_week,
        'pinned_notes': pinned_notes,
        'favorite_notes': favorite_notes,
        'notebooks': notebooks,
        'total_notes': all_notes.count(),
        'total_words': total_words,
        'total_cards_referenced': total_cards_referenced,
    }
    return render(request, 'notebook/dashboard.html', context)


@login_required
def note_create_view(request):
    """Criar nova nota - CORRIGIDO PARA EDITOR OVERLEAF"""
    if request.method == 'POST':
        try:
            # Validar dados obrigatórios
            title = request.POST.get('title', '').strip()
            content = request.POST.get('content', '').strip()
            
            if not title or not content:
                messages.error(request, 'Título e conteúdo são obrigatórios!')
                return redirect('note_create')
            
            # Criar nota
            note = Note(
                user=request.user,
                title=title,
                content=content,
                status=request.POST.get('status', 'draft'),
                priority=request.POST.get('priority', 'medium'),
                tags=request.POST.get('tags', ''),
                source=request.POST.get('source', ''),
                course=request.POST.get('course', ''),
                professor=request.POST.get('professor', ''),
            )
            
            # Caderno
            notebook_id = request.POST.get('notebook')
            if notebook_id:
                try:
                    note.notebook = Notebook.objects.get(pk=notebook_id, user=request.user)
                except Notebook.DoesNotExist:
                    pass
            
            note.save()
            
            # ============================================================
            # CORREÇÃO PARA EDITOR OVERLEAF: Cards podem vir como string
            # ============================================================
            cards_data = request.POST.get('cards', '')
            
            if cards_data:
                # Se vier como string "1,2,3" (do editor Overleaf)
                if isinstance(cards_data, str) and ',' in cards_data:
                    card_ids = [id.strip() for id in cards_data.split(',') if id.strip()]
                else:
                    # Se vier como lista (form normal)
                    card_ids = request.POST.getlist('cards')
                
                if card_ids:
                    try:
                        cards = Card.objects.filter(id__in=card_ids)
                        note.cards.set(cards)
                    except Exception as card_error:
                        # Log do erro mas não impede a criação da nota
                        print(f"Aviso: Erro ao vincular cards: {card_error}")
            
            messages.success(request, 'Nota criada com sucesso!')
            
            # ============================================================
            # CORREÇÃO: Usar pk ao invés de slug
            # ============================================================
            return redirect('note_detail', pk=note.pk)
            
        except Exception as e:
            messages.error(request, f'Erro ao salvar nota: {str(e)}')
            # Adicionar traceback para debug
            import traceback
            print("="*50)
            print("ERRO AO CRIAR NOTA:")
            print(traceback.format_exc())
            print("="*50)
            return redirect('note_create')
    
    # GET: Formulário
    notebooks = Notebook.objects.filter(user=request.user)
    
    # Tentar carregar cards, mas não falhar se não existir
    try:
        cards = Card.objects.all()
    except Exception as e:
        print(f"Aviso: Não foi possível carregar cards: {e}")
        cards = []
    
    context = {
        'notebooks': notebooks,
        'cards': cards,
    }
    return render(request, 'notebook/note_create.html', context)


@login_required
def note_detail_view(request, pk):  # CORRIGIDO: slug -> pk
    """Detalhes de uma nota"""
    note = get_object_or_404(Note, user=request.user, pk=pk)
    
    # Notas relacionadas (mesmo caderno ou mesmas tags)
    related_notes = Note.objects.filter(
        user=request.user
    ).filter(
        Q(notebook=note.notebook) | Q(tags__icontains=note.tags)
    ).exclude(pk=note.pk)[:4]
    
    context = {
        'note': note,
        'related_notes': related_notes,
        'revisions': note.revisions.all()[:10],
    }
    return render(request, 'notebook/note_detail.html', context)


@login_required
def note_edit_view(request, pk):  # CORRIGIDO: slug -> pk
    """Editar nota - CORRIGIDO PARA EDITOR OVERLEAF"""
    note = get_object_or_404(Note, user=request.user, pk=pk)
    
    if request.method == 'POST':
        try:
            # Salvar revisão antes de editar
            if request.POST.get('save_revision') == 'true':
                NoteRevision.objects.create(
                    note=note,
                    content=note.content,
                    revision_notes=request.POST.get('revision_notes', ''),
                    created_by=request.user
                )
            
            # Atualizar nota
            note.title = request.POST.get('title', note.title).strip()
            note.content = request.POST.get('content', note.content).strip()
            note.status = request.POST.get('status', note.status)
            note.priority = request.POST.get('priority', note.priority)
            note.tags = request.POST.get('tags', '')
            note.source = request.POST.get('source', '')
            note.course = request.POST.get('course', '')
            note.professor = request.POST.get('professor', '')
            
            # Caderno
            notebook_id = request.POST.get('notebook')
            if notebook_id:
                try:
                    note.notebook = Notebook.objects.get(pk=notebook_id, user=request.user)
                except Notebook.DoesNotExist:
                    note.notebook = None
            else:
                note.notebook = None
            
            note.save()
            
            # ============================================================
            # CORREÇÃO PARA EDITOR OVERLEAF: Cards podem vir como string
            # ============================================================
            cards_data = request.POST.get('cards', '')
            
            if cards_data:
                # Se vier como string "1,2,3" (do editor Overleaf)
                if isinstance(cards_data, str) and ',' in cards_data:
                    card_ids = [id.strip() for id in cards_data.split(',') if id.strip()]
                else:
                    # Se vier como lista (form normal)
                    card_ids = request.POST.getlist('cards')
                
                if card_ids:
                    try:
                        cards = Card.objects.filter(id__in=card_ids)
                        note.cards.set(cards)
                    except Exception as card_error:
                        print(f"Aviso: Erro ao atualizar cards: {card_error}")
            else:
                note.cards.clear()
            
            messages.success(request, 'Nota atualizada com sucesso!')
            
            # ============================================================
            # CORREÇÃO: Usar pk ao invés de slug
            # ============================================================
            return redirect('note_detail', pk=note.pk)
            
        except Exception as e:
            messages.error(request, f'Erro ao atualizar nota: {str(e)}')
            return redirect('note_edit', pk=note.pk)
    
    # GET: Formulário preenchido
    notebooks = Notebook.objects.filter(user=request.user)
    try:
        cards = Card.objects.all()
    except:
        cards = []
    
    context = {
        'note': note,
        'notebooks': notebooks,
        'cards': cards,
    }
    return render(request, 'notebook/note_edit.html', context)


@login_required
def note_delete_view(request, pk):  # CORRIGIDO: slug -> pk
    """Deletar nota"""
    note = get_object_or_404(Note, user=request.user, pk=pk)
    
    if request.method == 'POST':
        note.delete()
        messages.success(request, 'Nota excluída com sucesso!')
        return redirect('notebook')
    
    context = {'note': note}
    return render(request, 'notebook/note_confirm_delete.html', context)


@login_required
def note_toggle_favorite(request, pk):  # CORRIGIDO: slug -> pk
    """Toggle favorito"""
    note = get_object_or_404(Note, user=request.user, pk=pk)
    note.is_favorite = not note.is_favorite
    note.save()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'is_favorite': note.is_favorite
        })
    
    return redirect('note_detail', pk=note.pk)


@login_required
def note_toggle_pin(request, pk):  # CORRIGIDO: slug -> pk
    """Toggle fixar"""
    note = get_object_or_404(Note, user=request.user, pk=pk)
    note.is_pinned = not note.is_pinned
    note.save()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'is_pinned': note.is_pinned
        })
    
    return redirect('note_detail', pk=note.pk)


# ============================================================================
# API ENDPOINTS
# ============================================================================

@login_required
def api_notes_list(request):
    """API: Listar notas do usuário"""
    notes = Note.objects.filter(user=request.user)
    
    # Filtros
    status = request.GET.get('status')
    notebook_id = request.GET.get('notebook')
    search = request.GET.get('search')
    
    if status:
        notes = notes.filter(status=status)
    if notebook_id:
        notes = notes.filter(notebook_id=notebook_id)
    if search:
        notes = notes.filter(
            Q(title__icontains=search) | Q(content__icontains=search)
        )
    
    notes_data = [{
        'id': note.id,
        'slug': note.slug,
        'title': note.title,
        'content': note.content[:200],  # Preview
        'status': note.status,
        'status_emoji': note.get_status_display_emoji(),
        'status_display': note.get_status_display(),
        'priority': note.priority,
        'priority_color': note.get_priority_color(),
        'notebook': note.notebook.name if note.notebook else None,
        'tags': note.get_tags_list(),
        'cards_count': note.cards.count(),
        'word_count': note.word_count(),
        'reading_time': note.reading_time(),
        'is_favorite': note.is_favorite,
        'is_pinned': note.is_pinned,
        'created_at': note.created_at.isoformat(),
        'updated_at': note.updated_at.isoformat(),
    } for note in notes[:50]]  # Limitar a 50 notas
    
    return JsonResponse({
        'success': True,
        'notes': notes_data,
        'total': notes.count()
    })


@login_required
def api_note_detail(request, pk):
    """API: Detalhes de uma nota"""
    try:
        note = get_object_or_404(Note, pk=pk, user=request.user)
        
        note_data = {
            'id': note.id,
            'slug': note.slug,
            'title': note.title,
            'content': note.content,
            'status': note.status,
            'priority': note.priority,
            'tags': note.get_tags_list(),
            'source': note.source,
            'course': note.course,
            'professor': note.professor,
            'notebook': {
                'id': note.notebook.id,
                'name': note.notebook.name,
                'icon': note.notebook.icon,
            } if note.notebook else None,
            'cards': [{
                'id': card.id,
                'title': card.title,
                'area': card.get_area_display() if hasattr(card, 'get_area_display') else card.area,
            } for card in note.cards.all()],
            'word_count': note.word_count(),
            'reading_time': note.reading_time(),
            'is_favorite': note.is_favorite,
            'is_pinned': note.is_pinned,
            'created_at': note.created_at.isoformat(),
            'updated_at': note.updated_at.isoformat(),
        }
        
        return JsonResponse({
            'success': True,
            'note': note_data
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=404)


@login_required
@require_http_methods(["POST"])
def api_note_create(request):
    """API: Criar nova nota"""
    try:
        # Tentar JSON primeiro, depois form data
        if request.content_type == 'application/json':
            data = json.loads(request.body)
        else:
            data = request.POST
        
        title = data.get('title', '').strip()
        content = data.get('content', '').strip()
        
        if not title or not content:
            return JsonResponse({
                'success': False,
                'error': 'Título e conteúdo são obrigatórios'
            }, status=400)
        
        # Criar nota
        note = Note.objects.create(
            user=request.user,
            title=title,
            content=content,
            status=data.get('status', 'draft'),
            priority=data.get('priority', 'medium'),
            tags=data.get('tags', ''),
            source=data.get('source', ''),
            course=data.get('course', ''),
            professor=data.get('professor', ''),
        )
        
        # Caderno
        notebook_id = data.get('notebook_id') or data.get('notebook')
        if notebook_id:
            try:
                note.notebook = Notebook.objects.get(pk=notebook_id, user=request.user)
                note.save()
            except Notebook.DoesNotExist:
                pass
        
        # ============================================================
        # CORREÇÃO: Cards - handle both form data and JSON
        # ============================================================
        if request.content_type == 'application/json':
            card_ids = data.get('card_ids', [])
        else:
            cards_data = request.POST.get('cards', '')
            if isinstance(cards_data, str) and ',' in cards_data:
                card_ids = [id.strip() for id in cards_data.split(',') if id.strip()]
            else:
                card_ids = request.POST.getlist('cards')
        
        if card_ids:
            try:
                cards = Card.objects.filter(id__in=card_ids)
                note.cards.set(cards)
            except Exception as e:
                print(f"Aviso: Erro ao vincular cards via API: {e}")
        
        return JsonResponse({
            'success': True,
            'note_id': note.id,
            'slug': note.slug,
            'message': 'Nota criada com sucesso!'
        })
        
    except Exception as e:
        import traceback
        print("="*50)
        print("ERRO NA API DE CRIAÇÃO:")
        print(traceback.format_exc())
        print("="*50)
        return JsonResponse({
            'success': False,
            'error': f'Erro ao criar nota: {str(e)}'
        }, status=500)


@login_required
@require_http_methods(["POST"])
def api_note_update(request, pk):
    """API: Atualizar nota"""
    try:
        note = get_object_or_404(Note, pk=pk, user=request.user)
        data = json.loads(request.body) if request.content_type == 'application/json' else request.POST
        
        # Salvar revisão se solicitado
        if data.get('save_revision'):
            NoteRevision.objects.create(
                note=note,
                content=note.content,
                revision_notes=data.get('revision_notes', ''),
                created_by=request.user
            )
        
        # Atualizar campos
        note.title = data.get('title', note.title)
        note.content = data.get('content', note.content)
        note.status = data.get('status', note.status)
        note.priority = data.get('priority', note.priority)
        note.tags = data.get('tags', note.tags)
        note.save()
        
        # ============================================================
        # CORREÇÃO: Atualizar cards - handle both formats
        # ============================================================
        card_ids = data.get('card_ids')
        if card_ids is not None:
            if card_ids:
                try:
                    cards = Card.objects.filter(id__in=card_ids)
                    note.cards.set(cards)
                except Exception as e:
                    print(f"Aviso: Erro ao atualizar cards via API: {e}")
            else:
                note.cards.clear()
        
        return JsonResponse({
            'success': True,
            'message': 'Nota atualizada com sucesso!'
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


@login_required
@require_http_methods(["POST"])
def api_note_delete(request, pk):
    """API: Deletar nota"""
    try:
        note = get_object_or_404(Note, pk=pk, user=request.user)
        note.delete()
        
        return JsonResponse({
            'success': True,
            'message': 'Nota excluída com sucesso!'
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


@login_required
def api_cards_list(request):
    """API: Listar cards disponíveis"""
    try:
        cards = Card.objects.all()
        
        cards_data = [{
            'id': card.id,
            'title': card.title,
            'area': card.get_area_display() if hasattr(card, 'get_area_display') else card.area,
        } for card in cards]
        
        return JsonResponse({
            'success': True,
            'cards': cards_data
        })
    except Exception as e:
        return JsonResponse({
            'success': True,
            'cards': [],
            'warning': f'Cards não disponíveis: {str(e)}'
        })


@login_required
def api_notebooks_list(request):
    """API: Listar cadernos do usuário"""
    notebooks = Notebook.objects.filter(user=request.user)
    
    notebooks_data = [{
        'id': notebook.id,
        'name': notebook.name,
        'icon': notebook.icon,
        'color': notebook.color,
        'notes_count': notebook.notes.count(),
    } for notebook in notebooks]
    
    return JsonResponse({
        'success': True,
        'notebooks': notebooks_data
    })