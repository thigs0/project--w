from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Conversation(models.Model):
    """Conversa do usuário com o chatbot"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='conversations')
    title = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-updated_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.title or 'Nova conversa'}"
    
    def update_title(self):
        """Atualiza título baseado na primeira mensagem do usuário"""
        if not self.title:
            first_message = self.messages.filter(role='user').first()
            if first_message:
                self.title = first_message.content[:50] + ('...' if len(first_message.content) > 50 else '')
                self.save(update_fields=['title'])


class Message(models.Model):
    """Mensagem individual na conversa"""
    ROLE_CHOICES = [
        ('user', 'Usuário'),
        ('assistant', 'Assistente'),
        ('system', 'Sistema'),
    ]
    
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='messages')
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    # Metadados para recomendações
    recommended_cards = models.ManyToManyField('cards.Card', blank=True, related_name='recommendations')
    recommended_users = models.ManyToManyField(User, blank=True, related_name='profile_recommendations')
    
    class Meta:
        ordering = ['created_at']
    
    def __str__(self):
        return f"{self.role}: {self.content[:50]}"


class LearningTrail(models.Model):
    """Trilha de aprendizado personalizada gerada pelo chatbot"""
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='trails', null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='learning_trails')
    title = models.CharField(max_length=200)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    completed = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
    
    @property
    def progress_percentage(self):
        """Calcula % de conclusão da trilha"""
        total = self.steps.count()
        if total == 0:
            return 0
        completed = self.steps.filter(completed=True).count()
        return int((completed / total) * 100)


class TrailStep(models.Model):
    """Passo individual de uma trilha"""
    trail = models.ForeignKey(LearningTrail, on_delete=models.CASCADE, related_name='steps')
    order = models.IntegerField()
    title = models.CharField(max_length=200)
    description = models.TextField()
    estimated_hours = models.IntegerField(default=1, help_text='Horas estimadas para completar')
    
    # Recursos relacionados
    related_cards = models.ManyToManyField('cards.Card', blank=True, related_name='trail_steps')
    related_projects = models.ManyToManyField('projects.Project', blank=True, related_name='trail_steps')
    
    # Progresso
    completed = models.BooleanField(default=False)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        ordering = ['order']
        unique_together = ['trail', 'order']
    
    def __str__(self):
        return f"{self.order}. {self.title}"
    
    def mark_complete(self):
        """Marcar passo como concluído"""
        self.completed = True
        self.completed_at = timezone.now()
        self.save()