from django.db import models
from django.contrib.auth.models import User

class Card(models.Model):
    """Card de conhecimento"""
    AREA_CHOICES = [
        ('mathematics', 'Matemática'),
        ('physics', 'Física'),
        ('chemistry', 'Química'),
        ('biology', 'Biologia'),
        ('computer_science', 'Ciência da Computação'),
        ('engineering', 'Engenharia'),
        ('arts', 'Artes'),
        ('humanities', 'Humanidades'),
        ('business', 'Negócios'),
        ('other', 'Outros'),
    ]
    
    AREA_COLORS = {
        'mathematics': '#4A90E2',
        'physics': '#E24A4A',
        'chemistry': '#50C878',
        'biology': '#9B59B6',
        'computer_science': '#F39C12',
        'engineering': '#34495E',
        'arts': '#E91E63',
        'humanities': '#8B4513',
        'business': '#2ECC71',
        'other': '#95A5A6',
    }
    
    title = models.CharField(max_length=200)
    summary = models.CharField(max_length=300)
    content = models.TextField()
    area = models.CharField(max_length=50, choices=AREA_CHOICES, default='other')
    subareas = models.CharField(max_length=200, blank=True, help_text='Tags separadas por vírgula')
    color = models.CharField(max_length=7, blank=True)  # hex color
    image = models.ImageField(upload_to='cards/', blank=True, null=True)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        # Definir cor automaticamente baseada na área
        if not self.color:
            self.color = self.AREA_COLORS.get(self.area, '#95A5A6')
        super().save(*args, **kwargs)
    
    def get_subareas_list(self):
        """Retorna lista de subareas"""
        return [s.strip() for s in self.subareas.split(',') if s.strip()]
