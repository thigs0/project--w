from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from .models import Profile
from django.http import JsonResponse
from django.views.decorators.http import require_POST, require_GET

def register_view(request):
    """Página de registro"""
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Conta criada com sucesso!')
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'accounts/register.html', {'form': form})

def login_view(request):
    """Página de login"""
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Bem-vindo, {username}!')
                return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'accounts/login.html', {'form': form})

def profile_view(request, username):
    """Página de perfil do usuário"""
    user = get_object_or_404(User, username=username)
    # Buscar cards e projetos do usuário
    cards = user.card_set.all()[:6]  # 6 cards mais recentes
    projects = user.owned_projects.all()[:3]  # 3 projetos mais recentes ✅ CORRIGIDO
    
    context = {
        'profile_user': user,
        'cards': cards,
        'projects': projects,
    }
    return render(request, 'accounts/profile.html', context)

@login_required
def edit_profile_view(request):
    """Editar perfil do usuário"""
    if request.method == 'POST':
        user = request.user
        profile = user.profile
        
        user.first_name = request.POST.get('first_name', '')
        user.last_name = request.POST.get('last_name', '')
        user.save()
        
        profile.bio = request.POST.get('bio', '')
        profile.area_of_interest = request.POST.get('area_of_interest', '')
        
        if 'photo' in request.FILES:
            profile.photo = request.FILES['photo']
        
        profile.save()
        messages.success(request, 'Perfil atualizado com sucesso!')
        return redirect('profile', username=user.username)
    
    return render(request, 'accounts/edit_profile.html')


@require_POST
def api_login(request):
    username = request.POST.get('username')
    password = request.POST.get('password')
    user = authenticate(username=username, password=password)
    if user is not None:
        login(request, user)
        return JsonResponse({'ok': True, 'username': user.username, 'name': user.get_full_name()})
    return JsonResponse({'ok': False, 'error': 'Invalid credentials'}, status=400)


@require_POST
def api_logout(request):
    auth_logout(request)
    return JsonResponse({'ok': True})


@require_GET
def api_current_user(request):
    if request.user.is_authenticated:
        return JsonResponse({'authenticated': True, 'username': request.user.username, 'name': request.user.get_full_name()})
    return JsonResponse({'authenticated': False})