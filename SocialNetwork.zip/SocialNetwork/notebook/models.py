from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify
from cards.models import Card

class Notebook(models.Model):
    """Caderno/Pasta para organizar notas"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notebooks')
    name = models.CharField(max_length=200, help_text='Nome do caderno')
    slug = models.SlugField(max_length=220, blank=True)
    description = models.TextField(blank=True, help_text='DescriÃ§Ã£o do caderno')
    color = models.CharField(max_length=7, default='#7C3AED', help_text='Cor de destaque')
    icon = models.CharField(max_length=10, default='ðŸ““', help_text='Emoji representativo')
    is_favorite = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-is_favorite', '-updated_at']
        unique_together = ['user', 'slug']
    
    def __str__(self):
        return f"{self.icon} {self.name}"
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)
    
    def notes_count(self):
        return self.notes.count()
    
    def total_words(self):
        return sum(len(note.content.split()) for note in self.notes.all())


class Note(models.Model):
    """Nota no caderno pessoal"""
    STATUS_CHOICES = [
        ('draft', 'Rascunho'),
        ('review', 'Em RevisÃ£o'),
        ('final', 'Finalizado'),
        ('archived', 'Arquivado'),
    ]
    
    PRIORITY_CHOICES = [
        ('low', 'Baixa'),
        ('medium', 'MÃ©dia'),
        ('high', 'Alta'),
        ('urgent', 'Urgente'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notes')
    notebook = models.ForeignKey(
        Notebook, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='notes',
        help_text='Caderno/pasta onde estÃ¡ a nota'
    )
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, blank=True)
    content = models.TextField(help_text='Suporta Markdown e LaTeX')
    
    # OrganizaÃ§Ã£o
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='medium')
    tags = models.CharField(max_length=500, blank=True, help_text='Tags separadas por vÃ­rgula')
    
    # Relacionamentos
    cards = models.ManyToManyField(Card, blank=True, related_name='notes')
    
    # Metadados acadÃªmicos
    source = models.CharField(max_length=300, blank=True, help_text='Fonte/ReferÃªncia')
    course = models.CharField(max_length=200, blank=True, help_text='Disciplina/Curso')
    professor = models.CharField(max_length=200, blank=True, help_text='Professor')
    
    # Controle
    is_pinned = models.BooleanField(default=False, help_text='Fixar no topo')
    is_favorite = models.BooleanField(default=False)
    is_public = models.BooleanField(default=False, help_text='Compartilhar com a comunidade')
    
    # Datas
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_reviewed = models.DateTimeField(null=True, blank=True, help_text='Ãšltima revisÃ£o')
    
    class Meta:
        ordering = ['-is_pinned', '-updated_at']
        indexes = [
            models.Index(fields=['user', '-updated_at']),
            models.Index(fields=['user', 'status']),
            models.Index(fields=['user', 'is_favorite']),
        ]
    
    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title)
            slug = base_slug
            counter = 1
            while Note.objects.filter(user=self.user, slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)
    
    def get_tags_list(self):
        """Retorna lista de tags"""
        return [tag.strip() for tag in self.tags.split(',') if tag.strip()]
    
    def word_count(self):
        """Conta palavras no conteÃºdo"""
        return len(self.content.split())
    
    def reading_time(self):
        """Estima tempo de leitura (200 palavras/minuto)"""
        words = self.word_count()
        minutes = max(1, words // 200)
        return f"{minutes} min"
    
    def get_status_display_emoji(self):
        """Retorna emoji do status"""
        status_emojis = {
            'draft': 'ðŸ“',
            'review': 'ðŸ”',
            'final': 'âœ…',
            'archived': 'ðŸ“¦',
        }
        return status_emojis.get(self.status, 'ðŸ“„')
    
    def get_priority_color(self):
        """Retorna cor da prioridade"""
        priority_colors = {
            'low': '#95A5A6',
            'medium': '#3498DB',
            'high': '#F39C12',
            'urgent': '#E74C3C',
        }
        return priority_colors.get(self.priority, '#3498DB')


class NoteRevision(models.Model):
    """HistÃ³rico de revisÃµes de notas"""
    note = models.ForeignKey(Note, on_delete=models.CASCADE, related_name='revisions')
    content = models.TextField()
    revision_notes = models.TextField(blank=True, help_text='O que mudou nesta revisÃ£o')
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"RevisÃ£o de {self.note.title} em {self.created_at.strftime('%d/%m/%Y %H:%M')}"


class StudySession(models.Model):
    """SessÃ£o de estudo para tracking de produtividade"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='study_sessions')
    notes = models.ManyToManyField(Note, related_name='study_sessions')
    cards = models.ManyToManyField(Card, related_name='study_sessions')
    
    title = models.CharField(max_length=200, default='SessÃ£o de Estudos')
    description = models.TextField(blank=True)
    
    started_at = models.DateTimeField(auto_now_add=True)
    ended_at = models.DateTimeField(null=True, blank=True)
    duration_minutes = models.IntegerField(default=0)
    
    # MÃ©tricas
    notes_created = models.IntegerField(default=0)
    notes_reviewed = models.IntegerField(default=0)
    cards_studied = models.IntegerField(default=0)
    
    class Meta:
        ordering = ['-started_at']
    
    def __str__(self):
        return f"{self.title} - {self.started_at.strftime('%d/%m/%Y')}"