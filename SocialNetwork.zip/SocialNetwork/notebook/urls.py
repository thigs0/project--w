from django.urls import path
from . import views

urlpatterns = [
    # Dashboard principal
    path('', views.notebook_view, name='notebook'),
    
    # Cadernos (Notebooks)
    path('cadernos/', views.notebooks_view, name='notebooks_list'),
    path('cadernos/criar/', views.notebook_create_view, name='notebook_create'),
    path('cadernos/<slug:slug>/', views.notebook_detail_view, name='notebook_detail'),
    
    # ============================================================================
    # CORRIGIDO: Notas agora usam <int:pk> ao invés de <slug:slug>
    # ============================================================================
    path('nota/criar/', views.note_create_view, name='note_create'),
    path('nota/<int:pk>/', views.note_detail_view, name='note_detail'),
    path('nota/<int:pk>/editar/', views.note_edit_view, name='note_edit'),
    path('nota/<int:pk>/deletar/', views.note_delete_view, name='note_delete'),
    
    # Ações de notas
    path('nota/<int:pk>/favoritar/', views.note_toggle_favorite, name='note_toggle_favorite'),
    path('nota/<int:pk>/fixar/', views.note_toggle_pin, name='note_toggle_pin'),
    
    # API Endpoints para o overlay e AJAX
    path('api/notas/', views.api_notes_list, name='api_notes_list'),
    path('api/notas/<int:pk>/', views.api_note_detail, name='api_note_detail'),
    path('api/notas/criar/', views.api_note_create, name='api_note_create'),
    path('api/notas/<int:pk>/atualizar/', views.api_note_update, name='api_note_update'),
    path('api/notas/<int:pk>/deletar/', views.api_note_delete, name='api_note_delete'),
    path('api/cards/', views.api_cards_list, name='api_cards_list'),
    path('api/cadernos/', views.api_notebooks_list, name='api_notebooks_list'),
]