from django.contrib import admin
from .models import Project, ProjectRequest, ProjectTask, ProjectComment, ProjectMilestone

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ['title', 'type', 'status', 'owner', 'created_at', 'members_count']
    list_filter = ['type', 'status', 'visibility']
    search_fields = ['title', 'description', 'area']
    prepopulated_fields = {'slug': ('title',)}
    
    def members_count(self, obj):
        return obj.members.count()
    members_count.short_description = 'Membros'

@admin.register(ProjectRequest)
class ProjectRequestAdmin(admin.ModelAdmin):
    list_display = ['user', 'project', 'status', 'created_at']
    list_filter = ['status', 'created_at']
    
@admin.register(ProjectTask)
class ProjectTaskAdmin(admin.ModelAdmin):
    list_display = ['title', 'project', 'status', 'priority', 'assigned_to']
    list_filter = ['status', 'priority']

@admin.register(ProjectComment)
class ProjectCommentAdmin(admin.ModelAdmin):
    list_display = ['user', 'project', 'created_at']
    list_filter = ['created_at']

@admin.register(ProjectMilestone)
class ProjectMilestoneAdmin(admin.ModelAdmin):
    list_display = ['title', 'project', 'target_date', 'completed']
    list_filter = ['completed', 'target_date']