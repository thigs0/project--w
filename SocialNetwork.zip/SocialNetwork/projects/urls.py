from django.urls import path
from . import views

urlpatterns = [
    # Listagem
    path('', views.project_list_view, name='project_list'),
    path('meus-projetos/', views.my_projects_view, name='my_projects'),
    
    # CRUD
    path('criar/', views.project_create_view, name='project_create'),
    path('<slug:slug>/', views.project_detail_view, name='project_detail'),
    path('<slug:slug>/editar/', views.project_edit_view, name='project_edit'),
    path('<slug:slug>/deletar/', views.project_delete_view, name='project_delete'),
    
    # Sistema de Solicitações
    path('<slug:slug>/solicitar/', views.project_request_join, name='project_request_join'),
    path('<slug:slug>/solicitacoes/', views.project_requests_view, name='project_requests'),
    path('<slug:slug>/solicitacoes/<int:request_id>/aprovar/', views.project_request_approve, name='project_request_approve'),
    path('<slug:slug>/solicitacoes/<int:request_id>/rejeitar/', views.project_request_reject, name='project_request_reject'),
    path('<slug:slug>/sair/', views.project_leave, name='project_leave'),
]