from django.shortcuts import render
from cards.models import Card
from feed.models import Post

def home_view(request):
    """Página inicial"""
    # Exibir cards em destaque
    featured_cards = Card.objects.all()[:8]
    # Posts recentes
    recent_posts = Post.objects.all()[:3]
    
    context = {
        'featured_cards': featured_cards,
        'recent_posts': recent_posts,
    }
    return render(request, 'core/home.html', context)